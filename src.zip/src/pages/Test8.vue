<template>
    <div   class='all_bg' >
        <div  class='test_middle' >
            <div  class='test_option' ></div>
            <div  class='question_A' @click="toAfterQuestion(3)"></div>
            <div  class='question_B' @click="toAfterQuestion(2)"></div>
            <div  class='question_C' @click="toAfterQuestion(1)"></div>
            <div  class='test_icon_one' ></div>
            <div  class='test_icon_two' ></div>
            <div  class='test_icon_three' ></div>
            <div  class='test_icon_four' ></div>
            <div  class='test_icon_five' ></div>
            <div  class='test_icon_six' ></div>
            <div  class='test_icon_seven' ></div>
            <div  class='test_font' ></div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                val: ''
            };
        },
        created() {
            this.saveValue()
            this.wbuid = localStorage.getItem('wbuid')
            console.log(this.val)
        },
        methods: {
            saveValue() {
                let value = this.$route.params.value
                this.val = value
            },
            toAfterQuestion(e) {
                var score = e + this.val;
                this.saveById(score)
                if (e + this.val >= 8 && e + this.val <= 10) {
                    this.$router.push({
                        name: 'Result1'
                    });
                } else if (e + this.val > 10 && e + this.val <= 17) {
                    this.$router.push({
                        name: 'Result2'
                    });
                } else if (e + this.val > 17 && e + this.val < 24) {
                    this.$router.push({
                        name: 'Result3'
                    });
                } else if (e + this.val == 24) {
                    this.$router.push({
                        name: 'Result4'
                    });
                }
            },
            saveById(sco){
                var jg1 = sco;
                var vm = this;
                this.$axios({
                method: 'post',
                url:'/wbo/user/insert',
                data: {
                    uid:this.wbuid,
                    jg:jg1,
                },
            }).then((res)=>{
                
            });

            }
            
        },
    }
</script>

<style  scoped>
.all_bg{
    width:100%;
    height:100vh;
    background:url('../assets/images/test_bg.png') no-repeat center;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
}
.test_middle{
    position: relative;
    width:282px;
    height:476px;
    border: 2px solid #010101;
    border-radius: 6px;
    background-color: #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.test_option{
    width:228px;
    height:39px;
    background:url('../assets/images/question8.png') no-repeat center;
    background-size: cover;
    margin: 125px 27px 0 31px;
}
.question_A {
    width:228px;
    height:94px;
    background:url('../assets/images/question8A.png') no-repeat center;
    background-size: cover;
    margin: 5px 27px 0 30px;
}
.question_B {
    width:230px;
    height:90px;
    background:url('../assets/images/question8B.png') no-repeat center;
    background-size: cover;
    margin: 14px 27px 26px 30px;
}
.question_C {
    width:228px;
    height:62px;
    background:url('../assets/images/question8C.png') no-repeat center;
    background-size: cover;
    margin: 0 27px 0 30px;
}

.test_font {
    position: absolute;
    top: 42px;
    width:206px;
    height:61px;
    background:url('../assets/images/test_font.png') no-repeat center;
    background-size: cover;
}
.test_icon_one {
    position: absolute;
    top: -28px;
    left: 179px;
    width:98px;
    height:11px;
    background:url('../assets/images/test_icon1.png') no-repeat center;
    background-size: cover;
}
.test_icon_two {
    position: absolute;
    top: 103px;
    left: 37px;
    width:144px;
    height:6px;
    background:url('../assets/images/test_icon2.png') no-repeat center;
    background-size: cover;
}
.test_icon_three {
    position: absolute;
    top: -10px;
    left: -9px;
    width:23px;
    height:23px;
    background:url('../assets/images/test_icon3.png') no-repeat center;
    background-size: cover;
}
.test_icon_four {
    position: absolute;
    top: 27px;
    left: 6px;
    width:10px;
    height:60px;
    background:url('../assets/images/test_icon4.png') no-repeat center;
    background-size: cover;
}
.test_icon_five {
    position: absolute;
    top: 19px;
    left: 240px;
    width:54px;
    height:33px;
    background:url('../assets/images/test_icon5.png') no-repeat center;
    background-size: cover;
}
.test_icon_six {
    position: absolute;
    top: 108px;
    left: -13px;
    width:32px;
    height:53px;
    background:url('../assets/images/test_icon6.png') no-repeat center;
    background-size: cover;
}
.test_icon_seven {
    position: absolute;
    bottom: -55px;
    left: 215px;
    width:79px;
    height:43px;
    background:url('../assets/images/test_icon7.png') no-repeat center;
    background-size: cover;
}
</style>